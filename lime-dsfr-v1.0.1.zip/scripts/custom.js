/**
 * JavaScript personnalisé pour le thème DSFR
 *
 * Utilisez ce fichier pour vos scripts personnalisés
 * sans modifier theme.js
 */

(function() {
    'use strict';

    // Vos scripts personnalisés ici

})();
