![LimeSurvey Logo](https://account.limesurvey.org/images/logos/logo_main.png)
# LimeSurvey Bootstrap Vanilla Survey Theme

## Print answers directory

The views to print the survey.
In future version of LimeSurvey (3.5 or 4.x ) the subfolder "question_type" will not exist anymore, and each question theme will have its own view for the print rendering.
**If you create a template from scratchn, you can update the content of those files, but keep the structure of that directory (file name, directories, etc)**
