// here you can create custom JavaScript for the surveytheme options page
// the default one can be found in assets/packages/themeoptions-core/themeoptions-core.js
// to activate this file replace <optionspage>core</optionspage> with <optionspage>custom</optionspage> in the config.xml of this theme